
#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(ArgMaxWithValueTilingData)
TILING_DATA_FIELD_DEF(uint16_t, dim_reduce);
TILING_DATA_FIELD_DEF(uint16_t, dim_element_wise);
TILING_DATA_FIELD_DEF(uint16_t, dim_element_wise_total);
TILING_DATA_FIELD_DEF(uint8_t, mode);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(ArgMaxWithValue, ArgMaxWithValueTilingData)
}