
#include "arg_max_with_value_tiling.h"
#include "register/op_def_registry.h"
#include "graph/utils/type_utils.h"
// #include "tiling/platform/platform_ascendc.h"


namespace optiling {
static ge::graphStatus TilingFunc(gert::TilingContext* context)
{
    // get hardware info
    // auto ascendcPlatform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    // uint32_t num_cores = ascendcPlatform.GetCoreNum();
    uint32_t num_cores = 40;
    // printf("core num %d\n", num_cores);
    // get shape and attr
    uint32_t bytes_per_elem = 0;
    ge::TypeUtils::GetDataTypeLength(context->GetInputDesc(0)->GetDataType(), bytes_per_elem);
    const gert::Shape &x_shape = context->GetInputShape(0)->GetOriginShape();
    const int64_t dimension = *(context->GetAttrs()->GetInt(0));
    // calculate tiling
    ArgMaxWithValueTilingData tiling;
    // printf("dimension %d\n", (int)dimension);
    // printf("x_shape dim %d\n", (int)x_shape.GetDimNum());
    int32_t x_dims = x_shape.GetDimNum();
    if(dimension + 1 == x_dims) {
        // 在最后一维上做reduce
        uint32_t elems_per_row = x_shape[dimension]; // 每行多少元素
        uint32_t elems_total = x_shape.GetShapeSize(); // 一共多少元素
        uint32_t rows_total = elems_total / elems_per_row; // 一共多少行
        uint32_t rows_per_core = (rows_total + num_cores - 1) / num_cores; // 每个核能分到多少行
        num_cores = (rows_total + rows_per_core - 1) / rows_per_core; // 去掉末尾不用干活的核
        // printf("elems_per_row %d\n", elems_per_row);
        // printf("elems_total %d\n", elems_total);
        // printf("rows_total %d\n", rows_total);
        // printf("rows_per_core %d\n", rows_per_core);
        // printf("num_cores %d\n", num_cores);
        tiling.set_mode(0);
        tiling.set_dim_reduce(elems_per_row);
        tiling.set_dim_element_wise(rows_per_core);
        tiling.set_dim_element_wise_total(rows_total);
    } else if(dimension == 0) {
        // 在第一维上做reduce
        uint32_t elems_per_col = x_shape[0]; // 每列多少元素
        uint32_t elems_total = x_shape.GetShapeSize(); // 一共多少元素
        uint32_t cols_total = elems_total / elems_per_col; // 一共多少列
        uint32_t cols_per_task = 32 / bytes_per_elem; // 单个子任务：每行内连续32字节
        uint32_t tasks_total = (cols_total + cols_per_task - 1) / cols_per_task; // 一共多少子任务
        uint32_t tasks_per_core = (tasks_total + num_cores - 1) / num_cores; // 每个核能分到多少子任务
        uint32_t cols_per_core = tasks_per_core * cols_per_task; // 每个核一共处理多少列
        num_cores = (tasks_total + tasks_per_core - 1) / tasks_per_core; // 去掉末尾不用干活的核
        // printf("elems_per_col %d\n", elems_per_col);
        // printf("elems_total %d\n", elems_total);
        // printf("cols_total %d\n", cols_total);
        // printf("cols_per_task %d\n", cols_per_task);
        // printf("tasks_total %d\n", tasks_total);
        // printf("tasks_per_core %d\n", tasks_per_core);
        // printf("cols_per_core %d\n", cols_per_core);
        // printf("num_cores %d\n", num_cores);
        tiling.set_mode(1);
        tiling.set_dim_reduce(elems_per_col);
        tiling.set_dim_element_wise(cols_per_core);
        tiling.set_dim_element_wise_total(cols_total);
    } else {
        // 在中间维做reduce，测试数据没有，不写了
        tiling.set_mode(2);
    }
    // set core number
    context->SetBlockDim(num_cores);
    // save tiling data
    tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());
    context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());
    size_t *currentWorkspace = context->GetWorkspaceSizes(1);
    currentWorkspace[0] = 0;
    return ge::GRAPH_SUCCESS;
}
}


namespace ge {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    const gert::Shape &x_shape = *context->GetInputShape(0);
    gert::Shape &indice_shape = *context->GetOutputShape(0);
    gert::Shape &values_shape = *context->GetOutputShape(1);
    const int64_t dimension = *(context->GetAttrs()->GetInt(0));
    const bool keep_dims = *(context->GetAttrs()->GetBool(1));
    values_shape = x_shape;
    if(keep_dims) {
        values_shape.SetDim(dimension, 1);
    } else {
        size_t num_dims = values_shape.GetDimNum();
        for(size_t i = dimension; i + 1 < num_dims; ++i)
            values_shape[i] = values_shape[i + 1];
        values_shape.SetDimNum(num_dims - 1);
    }
    indice_shape = values_shape;
    return GRAPH_SUCCESS;
}
}


namespace ops {
class ArgMaxWithValue : public OpDef {
public:
    explicit ArgMaxWithValue(const char* name) : OpDef(name)
    {
        this->Input("x")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_INT32, ge::DT_UINT8})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("indice")
            .ParamType(REQUIRED)
            .DataType({ge::DT_INT32, ge::DT_INT32, ge::DT_INT32, ge::DT_INT32})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("values")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_INT32, ge::DT_UINT8})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Attr("dimension").Int();
        this->Attr("keep_dims").AttrType(OPTIONAL).Bool(false);

        this->SetInferShape(ge::InferShape);

        this->AICore()
            .SetTiling(optiling::TilingFunc);
        this->AICore().AddConfig("ascend910b");

    }
};

OP_ADD(ArgMaxWithValue);
}
