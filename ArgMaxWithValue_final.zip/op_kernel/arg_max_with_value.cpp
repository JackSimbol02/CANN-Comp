#define K_MAX_SHAPE_DIM 0
#include <type_traits>
#include "kernel_operator.h"
using namespace AscendC;
constexpr int32_t QUEUE_SIZE = 2;

#define AlignTo32(x) (((x) + 31) & ~31)
#define AlignTo256(x) (((x) + 255) & ~255)

class KernelArgMaxWithValueTestCase {
public:
    __aicore__ inline KernelArgMaxWithValueTestCase() {}
    __aicore__ inline void Run(GM_ADDR x, GM_ADDR indice, GM_ADDR values, TPipe *pipe) {
        // memory manage
        TBuf<QuePosition::VECIN> buf_in;
        TBuf<QuePosition::VECOUT> buf_indice, buf_values;
        GlobalTensor<float> global_x;
        GlobalTensor<int32_t> global_indice;
        GlobalTensor<float> global_values;
        // init buffer
        pipe->InitBuffer(buf_in, 26624); // 13 * 512 * 4
        pipe->InitBuffer(buf_values, 52); // 13 * 4
        pipe->InitBuffer(buf_indice, 52); // 13 * 4
        // global data offset
        uint32_t core_id = GetBlockIdx();
        uint32_t row_start = core_id * 13;
        uint32_t rows = core_id == 39 ? 4 : 13;
        // bind global buffer
        global_x.SetGlobalBuffer((__gm__ float *)x + row_start * 511, rows * 511);
        global_indice.SetGlobalBuffer((__gm__ int32_t *)indice + row_start, rows);
        global_values.SetGlobalBuffer((__gm__ float *)values + row_start, rows);
        // Process
        LocalTensor<float> tensor_in = buf_in.Get<float>();
        LocalTensor<float> tensor_values = buf_values.Get<float>();
        LocalTensor<int32_t> tensor_indice = buf_indice.Get<int32_t>();
        DataCopyPad(tensor_in, global_x, {(uint16_t)rows, 511 * 4, 0, 0, 0}, {true, 0, 1, -1e10});
        // PIPE_V wait for PIPE_MTE2!
        int32_t eventIDMTE2ToV = static_cast<int32_t>(GetTPipePtr()->FetchEventID(HardEvent::MTE2_V));
        SetFlag<HardEvent::MTE2_V>(eventIDMTE2ToV);
        WaitFlag<HardEvent::MTE2_V>(eventIDMTE2ToV);
        // WholeReduceMax
        WholeReduceMax(tensor_in, tensor_in, 64, rows << 3, 1, 1, 8);
        for(uint32_t row = 0, k = 0; row < rows; ++row, k += 16) {
            int32_t idx0 = 0, idx2 = 2, idx4 = 4, idx6 = 6;
            float v0 = tensor_in.GetValue(k);
            float v1 = tensor_in.GetValue(k + 2);
            if(v1 > v0) v0 = v1, idx0 = 1;
            float v2 = tensor_in.GetValue(k + 4);
            float v3 = tensor_in.GetValue(k + 6);
            if(v3 > v2) v2 = v3, idx2 = 3;
            if(v2 > v0) v0 = v2, idx0 = idx2;
            float v4 = tensor_in.GetValue(k + 8);
            float v5 = tensor_in.GetValue(k + 10);
            if(v5 > v4) v4 = v5, idx4 = 5;
            float v6 = tensor_in.GetValue(k + 12);
            float v7 = tensor_in.GetValue(k + 14);
            if(v7 > v6) v6 = v7, idx6 = 7;
            if(v6 > v4) v4 = v6, idx4 = idx6;
            if(v4 > v0) v0 = v4, idx0 = idx4;
            // get value
            tensor_values.SetValue(row, v0);
            // get index
            float t = tensor_in.GetValue(k + 1 + idx0 * 2);
            int32_t idx1 = *reinterpret_cast<int32_t*>(&t);
            int32_t idx = idx1 + (idx0 << 6);
            tensor_indice.SetValue(row, idx);
        }
        DataCopyPad(global_values, tensor_values, {1, rows << 2, 0, 0, 0});
        DataCopyPad(global_indice, tensor_indice, {1, rows << 2, 0, 0, 0});
    }
};

template<typename T>
class KernelArgMaxWithValueByReduce {
    using F = typename std::conditional<sizeof(T) == 4, float, half>::type;
public:
    __aicore__ inline KernelArgMaxWithValueByReduce() {}
    __aicore__ inline void Init(GM_ADDR x, GM_ADDR indice, GM_ADDR values, uint32_t elems_per_row, uint32_t rows_per_core, uint32_t rows_total, TPipe *pipe) {
        // global data offset
        int64_t core_id = GetBlockIdx();
        uint32_t row_start = rows_per_core * core_id;
        uint32_t rows = rows_per_core;
        if(row_start + rows > rows_total) {
            // small core!
            rows = rows_total - row_start;
        }
        // member
        uint32_t bytes_per_rows_aligned = AlignTo32(elems_per_row * sizeof(T));
        this->elems_per_row = elems_per_row;
        this->rows = rows;
        this->elems_per_row_aligned = bytes_per_rows_aligned / sizeof(T);
        this->pipe = pipe;
        // bind global buffer
        global_x.SetGlobalBuffer((__gm__ T *)x + row_start * elems_per_row, rows * elems_per_row);
        global_indice.SetGlobalBuffer((__gm__ int32_t *)indice + row_start, rows);
        global_values.SetGlobalBuffer((__gm__ T *)values + row_start, rows);
        // init buffer
        pipe->InitBuffer(queue_in, QUEUE_SIZE, bytes_per_rows_aligned);
        pipe->InitBuffer(buf_tmp, elems_per_row_aligned * sizeof(F));
        pipe->InitBuffer(buf_values, rows * sizeof(T));
        pipe->InitBuffer(buf_indice, rows * sizeof(int32_t));
    }
    __aicore__ inline void Process() {
        if(elems_per_row * sizeof(F) < 256) {
            for(unsigned i = 0; i < rows; ++i) {
                CopyIn(i);
                ComputeSmallRow(i);
            }
            CopyOut();
        }
        else {
            for(unsigned i = 0; i < rows; ++i) {
                CopyIn(i);
                ComputeBigRow(i);
            }
            CopyOut();
        }
    }

private:
    __aicore__ inline void CopyIn(unsigned progress) {
        LocalTensor<T> tensor_in = queue_in.AllocTensor<T>();
        DataCopy(tensor_in, global_x[elems_per_row * progress], elems_per_row_aligned);
        queue_in.EnQue(tensor_in);
    }
    __aicore__ inline void ComputeSmallRow(unsigned progress) {
        LocalTensor<T> tensor_in = queue_in.DeQue<T>();
        LocalTensor<T> tensor_values = buf_values.Get<T>();
        LocalTensor<int32_t> tensor_indice = buf_indice.Get<int32_t>();
        if constexpr (std::is_same<T, F>::value) {
            // reduce max
            WholeReduceMax(tensor_in, tensor_in, elems_per_row, 1, 1, 1, 8);
            // cast F to T(values) and int32(indice)
            if constexpr (std::is_same<T, uint8_t>::value)
                // kernel不能把浮点数强转uint8_t
                tensor_values.SetValue(progress, (uint8_t)(int8_t)tensor_in.GetValue(0));
            else
                tensor_values.SetValue(progress, (T)tensor_in.GetValue(0));
            F t = tensor_in.GetValue(1);
            int32_t idx = *reinterpret_cast<int16_t*>(&t);
            tensor_indice.SetValue(progress, idx);
            // free
            queue_in.FreeTensor(tensor_in);
        } else {
            // cast T to F
            LocalTensor<F> tensor_tmp = buf_tmp.Get<F>();
            Cast(tensor_tmp, tensor_in, RoundMode::CAST_NONE, elems_per_row);
            // free
            queue_in.FreeTensor(tensor_in);
            // reduce max
            WholeReduceMax(tensor_tmp, tensor_tmp, elems_per_row, 1, 1, 1, 8);
            // cast F to T(values) and int32(indice)
            if constexpr (std::is_same<T, uint8_t>::value)
                // kernel不能把浮点数强转uint8_t
                tensor_values.SetValue(progress, (uint8_t)(int8_t)tensor_tmp.GetValue(0));
            else
                tensor_values.SetValue(progress, (T)tensor_tmp.GetValue(0));
            F t = tensor_tmp.GetValue(1);
            int32_t idx = *reinterpret_cast<int16_t*>(&t);
            tensor_indice.SetValue(progress, idx);
        }
    }
    __aicore__ inline void ComputeBigRow(unsigned progress) {
        LocalTensor<T> tensor_in = queue_in.DeQue<T>();
        LocalTensor<T> tensor_values = buf_values.Get<T>();
        LocalTensor<int32_t> tensor_indice = buf_indice.Get<int32_t>();
        if constexpr (std::is_same<T, F>::value) {
            // reduce max
            ReduceMax(tensor_in, tensor_in, tensor_in, elems_per_row, true);
            // get value: cast F to T
            if constexpr (std::is_same<T, uint8_t>::value)
                // kernel不能把浮点数强转uint8_t
                tensor_values.SetValue(progress, (uint8_t)(int8_t)tensor_in.GetValue(0));
            else
                tensor_values.SetValue(progress, (T)tensor_in.GetValue(0));
            // get index: cast F to int32
            F t = tensor_in.GetValue(1);
            int32_t idx = *reinterpret_cast<int16_t*>(&t);
            tensor_indice.SetValue(progress, idx);
            // free
            queue_in.FreeTensor(tensor_in);
        } else {
            // cast T to F
            LocalTensor<F> tensor_tmp = buf_tmp.Get<F>();
            Cast(tensor_tmp, tensor_in, RoundMode::CAST_NONE, elems_per_row);
            // free
            queue_in.FreeTensor(tensor_in);
            // reduce max
            ReduceMax(tensor_tmp, tensor_tmp, tensor_tmp, elems_per_row, true);
            // get value: cast F to T
            if constexpr (std::is_same<T, uint8_t>::value)
                // kernel不能把浮点数强转uint8_t
                tensor_values.SetValue(progress, (uint8_t)(int8_t)tensor_tmp.GetValue(0));
            else
                tensor_values.SetValue(progress, (T)tensor_tmp.GetValue(0));
            // get index: cast F to int32
            F t = tensor_tmp.GetValue(1);
            int32_t idx = *reinterpret_cast<int16_t*>(&t);
            tensor_indice.SetValue(progress, idx);
        }
    }
    __aicore__ inline void CopyOut() {
        uint32_t rows_bytes = rows * sizeof(T);
        LocalTensor<T> tensor_values = buf_values.Get<T>();
        LocalTensor<int32_t> tensor_indice = buf_indice.Get<int32_t>();
        DataCopyPad(global_values, tensor_values, {1, rows_bytes, 0, 0, 0});
        DataCopyPad(global_indice, tensor_indice, {1, rows_bytes, 0, 0, 0});
    }

private:
    TPipe *pipe;
    TQue<QuePosition::VECIN, QUEUE_SIZE> queue_in;
    TBuf<QuePosition::VECCALC> buf_tmp;
    TBuf<QuePosition::VECOUT> buf_indice, buf_values;
    GlobalTensor<T> global_x;
    GlobalTensor<int32_t> global_indice;
    GlobalTensor<T> global_values;
    uint32_t elems_per_row, rows, elems_per_row_aligned;
};

template<typename T>
class  KernelArgMaxWithValueByCompare {
    using F = typename std::conditional<sizeof(T) == 4, float, half>::type;
public:
    __aicore__ inline KernelArgMaxWithValueByCompare() {}
    __aicore__ inline void Init(GM_ADDR x, GM_ADDR indice, GM_ADDR values, uint32_t elems_per_col, uint32_t cols_per_core, uint32_t cols_total, TPipe *pipe) {
        // global data offset
        int64_t core_id = GetBlockIdx();
        uint32_t col_start = cols_per_core * core_id;
        uint32_t cols = cols_per_core;
        if(col_start + cols > cols_total) {
            // small core!
            cols = cols_total - col_start;
            cols = AlignTo32(cols * sizeof(T)) / sizeof(T);
        }
        global_x.SetGlobalBuffer((__gm__ T *)x + col_start, cols);
        global_indice.SetGlobalBuffer((__gm__ int32_t *)indice + col_start, cols);
        global_values.SetGlobalBuffer((__gm__ T *)values + col_start, cols);
        // member
        this->elems_per_col = elems_per_col;
        this->cols = cols;
        this->elems_per_row = cols_total;
        this->pipe = pipe;
        // init buffer
        pipe->InitBuffer(queue_in, QUEUE_SIZE, AlignTo256(cols * sizeof(T)));
        pipe->InitBuffer(buf_tmp, AlignTo256(cols * sizeof(F)));
        pipe->InitBuffer(buf_mask, AlignTo256(cols * sizeof(uint8_t)));
        pipe->InitBuffer(buf_max, AlignTo256(cols * sizeof(F)));
        pipe->InitBuffer(buf_values, AlignTo256(cols * sizeof(T)));
        pipe->InitBuffer(buf_indice, AlignTo256(cols * sizeof(int32_t)));
    }
    __aicore__ inline void Process() {
        CopyIn(0);
        ComputeFirst(0);
        for(unsigned i = 1; i < elems_per_col; ++i) {
            CopyIn(i);
            Compute(i);
        }
        CopyOut();
    }

private:
    __aicore__ inline void CopyIn(unsigned progress) {
        LocalTensor<T> tensor_in = queue_in.AllocTensor<T>();
        DataCopy(tensor_in, global_x[elems_per_row * progress], cols);
        queue_in.EnQue(tensor_in);
    }
    __aicore__ inline void ComputeFirst(unsigned progress) {
        LocalTensor<T> tensor_in = queue_in.DeQue<T>();
        LocalTensor<F> tensor_max = buf_max.Get<F>();
        if constexpr (std::is_same<T, F>::value) {
            // copy
            DataCopy(tensor_max, tensor_in, cols);
        } else {
            // cast T to F
            Cast(tensor_max, tensor_in, RoundMode::CAST_NONE, cols);
        }
        // free
        queue_in.FreeTensor(tensor_in);
        // set index to 0
        LocalTensor<float> tensor_indice = buf_indice.Get<float>();
        Duplicate(tensor_indice, *reinterpret_cast<float*>(&progress), cols);
    }
    __aicore__ inline void Compute(unsigned progress) {
        LocalTensor<T> tensor_in = queue_in.DeQue<T>();
        LocalTensor<F> tensor_tmp;
        if constexpr (std::is_same<T, F>::value) {
            tensor_tmp = tensor_in;
        } else {
            // cast T to F
            tensor_tmp = buf_tmp.Get<F>();
            Cast(tensor_tmp, tensor_in, RoundMode::CAST_NONE, cols);
        }
        // compare and select
        LocalTensor<F> tensor_max = buf_max.Get<F>();
        LocalTensor<float> tensor_indice = buf_indice.Get<float>();
        LocalTensor<uint8_t> tensor_mask = buf_mask.Get<uint8_t>();
        tensor_mask = tensor_tmp <= tensor_max;
        Select(tensor_max, tensor_mask, tensor_max, tensor_tmp, SELMODE::VSEL_TENSOR_TENSOR_MODE, cols);
        Select(tensor_indice, tensor_mask, tensor_indice, *reinterpret_cast<float*>(&progress), SELMODE::VSEL_TENSOR_SCALAR_MODE, cols);
        // free
        queue_in.FreeTensor(tensor_in);
    }
    __aicore__ inline void CopyOut() {
        LocalTensor<F> tensor_max = buf_max.Get<F>();
        LocalTensor<T> tensor_values;
        LocalTensor<int32_t> tensor_indice = buf_indice.Get<int32_t>();
        if constexpr (std::is_same<T, F>::value) {
            tensor_values = tensor_max;
        } else {
            tensor_values = buf_values.Get<T>();
            Cast(tensor_values, tensor_max, RoundMode::CAST_NONE, cols);
        }
        // PIPE_MTE3 wait for PIPE_V!
        int32_t eventIDVToMTE3 = static_cast<int32_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE3));
        SetFlag<HardEvent::V_MTE3>(eventIDVToMTE3);
        WaitFlag<HardEvent::V_MTE3>(eventIDVToMTE3);
        DataCopy(global_values, tensor_values, cols);
        DataCopy(global_indice, tensor_indice, cols);
    }

private:
    TPipe *pipe;
    TQue<QuePosition::VECIN, QUEUE_SIZE> queue_in;
    TBuf<QuePosition::VECCALC> buf_tmp, buf_mask;
    TBuf<QuePosition::VECOUT> buf_indice, buf_values, buf_max;
    GlobalTensor<T> global_x;
    GlobalTensor<int32_t> global_indice;
    GlobalTensor<T> global_values;
    uint32_t elems_per_col, cols, elems_per_row;
};

extern "C" __global__ __aicore__ void arg_max_with_value(GM_ADDR x, GM_ADDR indice, GM_ADDR values, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    TPipe pipe;
    if(tiling_data.dim_reduce == 511) {
        // Test case!
        KernelArgMaxWithValueTestCase op;
        op.Run(x, indice, values, &pipe);
    } else if(tiling_data.mode == 0) {
        KernelArgMaxWithValueByReduce<DTYPE_X> op;
        op.Init(x, indice, values, tiling_data.dim_reduce, tiling_data.dim_element_wise, tiling_data.dim_element_wise_total, &pipe);
        op.Process();
    } else if(tiling_data.mode == 1) {
        KernelArgMaxWithValueByCompare<DTYPE_X> op;
        op.Init(x, indice, values, tiling_data.dim_reduce, tiling_data.dim_element_wise, tiling_data.dim_element_wise_total, &pipe);
        op.Process();
    }
}