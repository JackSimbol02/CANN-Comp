
#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(NLLLossTilingData)
TILING_DATA_FIELD_DEF(uint16_t, classes);
TILING_DATA_FIELD_DEF(uint16_t, batches);
TILING_DATA_FIELD_DEF(uint8_t, reduction); // sum: 0, mean: 1
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(NLLLoss, NLLLossTilingData)
}
