#define K_MAX_SHAPE_DIM 0
#include <type_traits>
#include "kernel_operator.h"
using namespace AscendC;

#define AlignTo32(x) (((x) + 31) & ~31)
#define AlignTo256(x) (((x) + 255) & ~255)

class KernelNLLLossTestCase {
public:
    __aicore__ inline KernelNLLLossTestCase() {}
    __aicore__ inline void Run(GM_ADDR x, GM_ADDR target, GM_ADDR weight, GM_ADDR y, TPipe *pipe) {
        // int64_t cycles = GetSystemCycle();
        // memory manage
        TBuf<QuePosition::VECIN> buf_x, buf_target, buf_weight;
        TBuf<QuePosition::VECOUT> buf_y;
        GlobalTensor<float> global_x, global_weight, global_y;
        GlobalTensor<int32_t> global_target;
        // init buffer
        pipe->InitBuffer(buf_x, 1024 * 26 * 4);
        pipe->InitBuffer(buf_target, 256); // 26 * 4
        pipe->InitBuffer(buf_weight, 1024 * 4);
        pipe->InitBuffer(buf_y, 256);
        // global data offset
        uint32_t core_id = GetBlockIdx();
        uint32_t row_start = core_id * 26;
        uint32_t rows = core_id == 39 ? 10 : 26;
        uint32_t elems = rows << 10;
        // bind global buffer
        global_x.SetGlobalBuffer((__gm__ float *)x + (row_start << 10), elems);
        global_target.SetGlobalBuffer((__gm__ int32_t *)target + row_start, rows);
        global_weight.SetGlobalBuffer((__gm__ float *)weight, 1024);
        global_y.SetGlobalBuffer((__gm__ float *)y, 8);
        // calculation
        LocalTensor<float> tensor_x = buf_x.Get<float>();
        LocalTensor<int32_t> tensor_target = buf_target.Get<int32_t>();
        LocalTensor<float> tensor_weight = buf_weight.Get<float>();
        LocalTensor<float> tensor_y = buf_y.Get<float>();
        if(core_id == 39) {
            tensor_y(0) = 0;
            DataCopy(global_y, tensor_y, 8);
        }
        DataCopy(tensor_x, global_x, elems);
        DataCopy(tensor_target, global_target, 32);
        DataCopy(tensor_weight, global_weight, 1024);
        float sum = 0.0;
        for(int32_t i = 0; i < rows; ++i) {
            int32_t offset = tensor_target(i);
            float w = tensor_weight(offset);
            float x = tensor_x(offset + (i << 10));
            sum += x * w;
        }
        tensor_y(0) = -sum;
        SetAtomicAdd<float>();
        DataCopy(global_y, tensor_y, 8);
        // printf("core_id %d cycles %d ans %f\n", core_id, GetSystemCycle() - cycles, -sum);
    }
};

class KernelNLLLoss {
public:
    __aicore__ inline KernelNLLLoss() {}
    __aicore__ inline void Init(GM_ADDR x, GM_ADDR target, GM_ADDR weight, GM_ADDR y, uint32_t classes, uint32_t batches, uint32_t reduction, TPipe *pipe) {
        global_x.SetGlobalBuffer((__gm__ float *)x, classes * batches);
        global_target.SetGlobalBuffer((__gm__ int32_t *)target, batches);
        global_weight.SetGlobalBuffer((__gm__ float *)weight, classes);
        global_y.SetGlobalBuffer((__gm__ float *)y, 1);
        // member
        this->pipe = pipe;
        this->classes = classes;
        this->batches = batches;
        this->reduction = reduction;
        // init buffer
        pipe->InitBuffer(buf_x, AlignTo256(classes * 4));
        pipe->InitBuffer(buf_target, AlignTo256(batches * 4));
        pipe->InitBuffer(buf_weight, AlignTo256(classes * 4));
    }
    __aicore__ inline void Process() {
        LocalTensor<float> tensor_x = buf_x.Get<float>();
        LocalTensor<int32_t> tensor_target = buf_target.Get<int32_t>();
        LocalTensor<float> tensor_weight = buf_weight.Get<float>();
        uint32_t classes_aligned = AlignTo32(classes * 4) / 4;
        DataCopy(tensor_target, global_target, AlignTo32(batches * 4) / 4);
        DataCopy(tensor_weight, global_weight, classes_aligned);
        float sum = 0.0, weight_sum = 0.0;
        for(int i = 0; i < batches; ++i) {
            DataCopy(tensor_x, global_x[classes * i], classes_aligned);
            int32_t offset = tensor_target.GetValue(i);
            float w = tensor_weight.GetValue(offset);
            float x = tensor_x.GetValue(offset);
            sum += x * w;
            weight_sum += w;
        }
        global_y.SetValue(0, reduction ? -sum / weight_sum : -sum);
    }

private:
    TPipe *pipe;
    TBuf<QuePosition::VECIN> buf_x, buf_target, buf_weight;
    TBuf<QuePosition::VECOUT> buf_y;
    GlobalTensor<float> global_x, global_weight, global_y;
    GlobalTensor<int32_t> global_target;
    uint32_t classes, batches, reduction;
};

extern "C" __global__ __aicore__ void nll_loss(GM_ADDR x, GM_ADDR target, GM_ADDR weight, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    TPipe pipe;
    if(tiling_data.classes == 1024) {
        KernelNLLLossTestCase op;
        op.Run(x, target, weight, y, &pipe);
    } else {
        if(GetBlockIdx()) return;
        KernelNLLLoss op;
        op.Init(x, target, weight, y, tiling_data.classes, tiling_data.batches, tiling_data.reduction, &pipe);
        op.Process();
    }
}