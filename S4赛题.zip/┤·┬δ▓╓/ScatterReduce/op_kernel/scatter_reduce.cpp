#define K_MAX_SHAPE_DIM 0
#include "kernel_operator.h"

using namespace AscendC;

#define QUEUE_SIZE 1

template<int reduce, bool include_self>
class KernelScatterReduceByRow {
    using T = DTYPE_Y;
    using U = int32_t;
public:
    __aicore__ inline KernelScatterReduceByRow(
        GM_ADDR self, GM_ADDR index, GM_ADDR src, GM_ADDR y,
        int32_t dim_h, int32_t dim_m, int32_t tasks_per_core
    ) {
        // 一行元素作为一个任务
        // 当前核负责区间[start, end)的任务
        int32_t tasks_total = dim_h;
        int64_t core_id = GetBlockIdx();
        start = tasks_per_core * core_id;
        end = start + tasks_per_core;
        if(end > tasks_total) end = tasks_total;
        // 局部变量
        this->dim_h = dim_h;
        this->dim_m = dim_m;
        // 分配空间
        uint32_t buffer_size = (dim_m * sizeof(T) + 255) & ~255;
        uint32_t buffer_size_4 = (dim_m * 4 + 255) & ~255;
        pipe.InitBuffer(queue_self, QUEUE_SIZE, buffer_size);
        pipe.InitBuffer(queue_index, QUEUE_SIZE, buffer_size_4);
        pipe.InitBuffer(queue_src, QUEUE_SIZE, buffer_size);
        pipe.InitBuffer(buf_cnt, buffer_size_4);
        pipe.InitBuffer(buf_res, buffer_size_4);
        pipe.InitBuffer(queue_y, QUEUE_SIZE, buffer_size);
        // 全局tensor绑定buffer
        global_self.SetGlobalBuffer((__gm__ T *)self);
        global_index.SetGlobalBuffer((__gm__ U *)index);
        global_src.SetGlobalBuffer((__gm__ T *)src);
        global_y.SetGlobalBuffer((__gm__ T *)y);
        // 主循环
        for(int32_t h = start; h < end; ++h) {
            CopyIn(h);
            Compute();
            CopyOut(h);
        }
    }
    __aicore__ inline void CopyIn(int32_t h) {
        LocalTensor<T> tensor_self = queue_self.AllocTensor<T>();
        LocalTensor<U> tensor_index = queue_index.AllocTensor<U>();
        LocalTensor<T> tensor_src = queue_src.AllocTensor<T>();
        // 搬运输入，一次搬运一行dim_m个元素
        int32_t offset = h * dim_m;
        uint32_t size = dim_m * sizeof(T);
        uint32_t size_4 = dim_m * 4;
        DataCopyPad(tensor_self, global_self[offset], {1, size, 0, 0, 0}, {false, 0, 0, 0});
        DataCopyPad(tensor_index, global_index[offset], {1, size_4, 0, 0, 0}, {false, 0, 0, 0});
        DataCopyPad(tensor_src, global_src[offset], {1, size, 0, 0, 0}, {false, 0, 0, 0});
        queue_self.EnQue(tensor_self);
        queue_index.EnQue(tensor_index);
        queue_src.EnQue(tensor_src);
    }
    __aicore__ inline void Compute() {
        LocalTensor<T> tensor_self = queue_self.DeQue<T>();
        LocalTensor<U> tensor_index = queue_index.DeQue<U>();
        LocalTensor<T> tensor_src = queue_src.DeQue<T>();
        LocalTensor<T> tensor_y = queue_y.AllocTensor<T>();
        LocalTensor<float> tensor_res = buf_res.Get<float>();
        LocalTensor<U> tensor_cnt = buf_cnt.Get<U>();
        // reduce初值
        float init;
        if constexpr (reduce == 0 || reduce == 2) init = 0;
        if constexpr (reduce == 1) init = 1;
        if constexpr (reduce == 3) init = -1.0 / 0.0;
        if constexpr (reduce == 4) init = 1.0 / 0.0;
        Duplicate(tensor_res, init, dim_m);
        Duplicate(tensor_cnt, 0, dim_m);
        if constexpr (reduce == 0) { // sum
            for(int32_t i = 0; i < dim_m; ++i) {
                int32_t idx = tensor_index(i);
                tensor_res(idx) += static_cast<float>(tensor_src(i));
                tensor_cnt(idx) += 1;
            }
            for(int32_t i = 0; i < dim_m; ++i)
                if(tensor_cnt(i)) {
                    if constexpr (include_self)
                        tensor_res(i) += static_cast<float>(tensor_self(i));
                    tensor_y(i) = tensor_res(i);
                }
                else tensor_y(i) = tensor_self(i);
        }
        if constexpr (reduce == 1) { // prod
            for(int32_t i = 0; i < dim_m; ++i) {
                int32_t idx = tensor_index(i);
                tensor_res(idx) *= static_cast<float>(tensor_src(i));
                tensor_cnt(idx) += 1;
            }
            for(int32_t i = 0; i < dim_m; ++i)
                if(tensor_cnt(i)) {
                    if constexpr (include_self)
                        tensor_res(i) *= static_cast<float>(tensor_self(i));
                    tensor_y(i) = tensor_res(i);
                }
                else tensor_y(i) = tensor_self(i);
        }
        if constexpr (reduce == 2) { // mean
            for(int32_t i = 0; i < dim_m; ++i) {
                int32_t idx = tensor_index(i);
                tensor_res(idx) += static_cast<float>(tensor_src(i));
                tensor_cnt(idx) += 1;
            }
            for(int32_t i = 0; i < dim_m; ++i)
                if(tensor_cnt(i)) {
                    if constexpr (include_self) {
                        tensor_res(i) += static_cast<float>(tensor_self(i));
                        tensor_cnt(i) += 1;
                    }
                    tensor_y(i) = tensor_res(i) / tensor_cnt(i);
                }
                else tensor_y(i) = tensor_self(i);
        }
        if constexpr (reduce == 3) { // amax
            for(int32_t i = 0; i < dim_m; ++i) {
                int32_t idx = tensor_index(i);
                float f = static_cast<float>(tensor_src(i));
                if(f > tensor_res(idx)) tensor_res(idx) = f;
                tensor_cnt(idx) += 1;
            }
            for(int32_t i = 0; i < dim_m; ++i)
                if(tensor_cnt(i)) {
                    if constexpr (include_self) {
                        float f = static_cast<float>(tensor_self(i));
                        if(f > tensor_res(i)) tensor_res(i) = f;
                    }
                    tensor_y(i) = tensor_res(i);
                }
                else tensor_y(i) = tensor_self(i);
        }
        if constexpr (reduce == 4) { // amin
            for(int32_t i = 0; i < dim_m; ++i) {
                int32_t idx = tensor_index(i);
                float f = static_cast<float>(tensor_src(i));
                if(f < tensor_res(idx)) tensor_res(idx) = f;
                tensor_cnt(idx) += 1;
            }
            for(int32_t i = 0; i < dim_m; ++i)
                if(tensor_cnt(i)) {
                    if constexpr (include_self) {
                        float f = static_cast<float>(tensor_self(i));
                        if(f < tensor_res(i)) tensor_res(i) = f;
                    }
                    tensor_y(i) = tensor_res(i);
                }
                else tensor_y(i) = tensor_self(i);
        }
        queue_self.FreeTensor(tensor_self);
        queue_index.FreeTensor(tensor_index);
        queue_src.FreeTensor(tensor_src);
        queue_y.EnQue(tensor_y);
    }
    __aicore__ inline void CopyOut(int32_t h) {
        LocalTensor<T> tensor_y = queue_y.DeQue<T>();
        // 搬运输出
        uint32_t size = dim_m * sizeof(T);
        DataCopyPad(global_y[h * dim_m], tensor_y, {1, size, 0, 0, 0});
        queue_y.FreeTensor(tensor_y);
    }
private:
    TPipe pipe;
    TQue<QuePosition::VECIN, QUEUE_SIZE> queue_self, queue_index, queue_src;
    TBuf<QuePosition::VECCALC> buf_res, buf_cnt;
    TQue<QuePosition::VECOUT, QUEUE_SIZE> queue_y;
    GlobalTensor<T> global_self, global_src, global_y;
    GlobalTensor<U> global_index;
    int32_t dim_h, dim_m, start, end;
};

template<int reduce, bool include_self>
class KernelScatterReduceByColumnUnAligned {
    using T = DTYPE_Y;
    using U = int32_t;
public:
    __aicore__ inline KernelScatterReduceByColumnUnAligned(
        GM_ADDR self, GM_ADDR index, GM_ADDR src, GM_ADDR y,
        int32_t dim_h, int32_t dim_m, int32_t dim_l, int32_t tasks_per_core
    ) {
        // 一列单个元素作为一个任务
        // 当前核负责区间[start, end)的任务
        int32_t tasks_total = dim_h * dim_l;
        int64_t core_id = GetBlockIdx();
        int32_t start = tasks_per_core * core_id;
        int32_t end = start + tasks_per_core;
        if(end > tasks_total) end = tasks_total;
        // 分配空间
        uint32_t buffer_size = (dim_m * sizeof(T) + 255) & ~255;
        uint32_t buffer_size_4 = (dim_m * 4 + 255) & ~255;
        pipe.InitBuffer(buf_index, buffer_size_4);
        pipe.InitBuffer(buf_src, buffer_size);
        pipe.InitBuffer(buf_cnt, buffer_size_4);
        pipe.InitBuffer(buf_res, buffer_size_4);
        pipe.InitBuffer(buf_y, buffer_size);
        // 全局tensor绑定buffer
        global_self.SetGlobalBuffer((__gm__ T *)self);
        global_index.SetGlobalBuffer((__gm__ U *)index);
        global_src.SetGlobalBuffer((__gm__ T *)src);
        global_y.SetGlobalBuffer((__gm__ T *)y);
        // 获取本地tensor
        LocalTensor<U> tensor_index = buf_index.Get<U>();
        LocalTensor<T> tensor_src = buf_src.Get<T>();
        LocalTensor<T> tensor_y = buf_y.Get<T>();
        LocalTensor<float> tensor_res = buf_res.Get<float>();
        LocalTensor<U> tensor_cnt = buf_cnt.Get<U>();
        // reduce初值
        float init;
        if constexpr (reduce == 0 || reduce == 2) init = 0;
        if constexpr (reduce == 1) init = 1;
        if constexpr (reduce == 3) init = -1.0 / 0.0;
        if constexpr (reduce == 4) init = 1.0 / 0.0;
        // 主循环
        for(int32_t tid = start, h = start / dim_l, l = start % dim_l; tid < end; ++tid) {
            // 搬运输入，一次搬运一列dim_m个元素
            for(int32_t i = 0, p = h * dim_m * dim_l + l; i < dim_m; ++i, p += dim_l) {
                tensor_y(i) = global_self(p);
                tensor_index(i) = global_index(p);
                tensor_src(i) = global_src(p);
            }
            // 计算
            Duplicate(tensor_res, init, dim_m);
            Duplicate(tensor_cnt, 0, dim_m);
            if constexpr (reduce == 0) { // sum
                for(int32_t i = 0; i < dim_m; ++i) {
                    int32_t idx = tensor_index(i);
                    tensor_res(idx) += static_cast<float>(tensor_src(i));
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0; i < dim_m; ++i)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self)
                            tensor_res(i) += static_cast<float>(tensor_y(i));
                        tensor_y(i) = tensor_res(i);
                    }
            }
            if constexpr (reduce == 1) { // prod
                for(int32_t i = 0; i < dim_m; ++i) {
                    int32_t idx = tensor_index(i);
                    tensor_res(idx) *= static_cast<float>(tensor_src(i));
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0; i < dim_m; ++i)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self)
                            tensor_res(i) *= static_cast<float>(tensor_y(i));
                        tensor_y(i) = tensor_res(i);
                    }
            }
            if constexpr (reduce == 2) { // mean
                for(int32_t i = 0; i < dim_m; ++i) {
                    int32_t idx = tensor_index(i);
                    tensor_res(idx) += static_cast<float>(tensor_src(i));
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0; i < dim_m; ++i)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self) {
                            tensor_res(i) += static_cast<float>(tensor_y(i));
                            tensor_cnt(i) += 1;
                        }
                        tensor_y(i) = tensor_res(i) / tensor_cnt(i);
                    }
            }
            if constexpr (reduce == 3) { // amax
                for(int32_t i = 0; i < dim_m; ++i) {
                    int32_t idx = tensor_index(i);
                    float f = static_cast<float>(tensor_src(i));
                    if(f > tensor_res(idx)) tensor_res(idx) = f;
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0; i < dim_m; ++i)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self) {
                            float f = static_cast<float>(tensor_y(i));
                            if(f > tensor_res(i)) tensor_res(i) = f;
                        }
                        tensor_y(i) = tensor_res(i);
                    }
            }
            if constexpr (reduce == 4) { // amin
                for(int32_t i = 0; i < dim_m; ++i) {
                    int32_t idx = tensor_index(i);
                    float f = static_cast<float>(tensor_src(i));
                    if(f < tensor_res(idx)) tensor_res(idx) = f;
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0; i < dim_m; ++i)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self) {
                            float f = static_cast<float>(tensor_y(i));
                            if(f < tensor_res(i)) tensor_res(i) = f;
                        }
                        tensor_y(i) = tensor_res(i);
                    }
            }
            // 搬运输出
            for(int32_t i = 0, p = h * dim_m * dim_l + l; i < dim_m; ++i, p += dim_l)
                global_y(p) = tensor_y(i);
            ++l; if(l == dim_l) ++h, l = 0;
        }
    }
private:
    TPipe pipe;
    TBuf<QuePosition::VECIN> buf_index, buf_src;
    TBuf<QuePosition::VECCALC> buf_res, buf_cnt;
    TBuf<QuePosition::VECOUT> buf_y;
    GlobalTensor<T> global_self, global_src, global_y;
    GlobalTensor<U> global_index;
};

template<int reduce, bool include_self>
class KernelScatterReduceByColumnAligned {
    using T = DTYPE_Y;
    using U = int32_t;
public:
    __aicore__ inline KernelScatterReduceByColumnAligned(
        TPipe *pipe,
        GM_ADDR self, GM_ADDR index, GM_ADDR src, GM_ADDR y,
        int32_t dim_h, int32_t dim_m, int32_t dim_l, int32_t tasks_per_core
    ) {
        // 一列32字节元素作为一个任务
        elems_per_task = 32 / sizeof(T);
        block_l = dim_l / elems_per_task;
        // 当前核负责区间[start, end)的任务
        int32_t tasks_total = dim_h * block_l;
        int64_t core_id = GetBlockIdx();
        start = tasks_per_core * core_id;
        end = start + tasks_per_core;
        if(end > tasks_total) end = tasks_total;
        // 局部变量
        this->dim_h = dim_h;
        this->dim_m = dim_m;
        this->dim_l = dim_l;
        // 分配空间
        uint32_t block_size = dim_m << 5;
        uint32_t block_size_4 = dim_m * elems_per_task << 2;
        uint32_t buffer_size = (dim_m * 4 + 255) & ~255;
        pipe->InitBuffer(queue_self, QUEUE_SIZE, block_size);
        pipe->InitBuffer(queue_index, QUEUE_SIZE, block_size_4);
        pipe->InitBuffer(queue_src, QUEUE_SIZE, block_size);
        pipe->InitBuffer(queue_y, QUEUE_SIZE, block_size);
        pipe->InitBuffer(buf_cnt, buffer_size);
        pipe->InitBuffer(buf_res, buffer_size);
        // 全局tensor绑定buffer
        global_self.SetGlobalBuffer((__gm__ T *)self);
        global_index.SetGlobalBuffer((__gm__ U *)index);
        global_src.SetGlobalBuffer((__gm__ T *)src);
        global_y.SetGlobalBuffer((__gm__ T *)y);
        // 主循环
        for(int32_t tid = start, h = start / block_l, l = start % block_l; tid < end; ++tid) {
            int32_t c = elems_per_task * l;
            CopyIn(h, c);
            Compute();
            CopyOut(h, c);
            ++l; if(l == block_l) ++h, l = 0;
        }
    }
    __aicore__ inline void CopyIn(int32_t h, int32_t c) {
        LocalTensor<T> tensor_self = queue_self.AllocTensor<T>();
        LocalTensor<U> tensor_index = queue_index.AllocTensor<U>();
        LocalTensor<T> tensor_src = queue_src.AllocTensor<T>();
        // 搬运输入，一次搬运同一列dim_m个datablock
        int32_t offset = h * dim_m * dim_l + c;
        DataCopyParams params{static_cast<uint16_t>(dim_m), 1, static_cast<uint16_t>(block_l - 1), 0};
        DataCopyParams params_4{static_cast<uint16_t>(dim_m), static_cast<uint16_t>(sizeof(U) / sizeof(T)), static_cast<uint16_t>((block_l - 1) * (sizeof(U) / sizeof(T))), 0};
        DataCopy(tensor_self, global_self[offset], params);
        DataCopy(tensor_index, global_index[offset], params_4);
        DataCopy(tensor_src, global_src[offset], params);
        queue_self.EnQue(tensor_self);
        queue_index.EnQue(tensor_index);
        queue_src.EnQue(tensor_src);
    }
    __aicore__ inline void Compute() {
        LocalTensor<T> tensor_self = queue_self.DeQue<T>();
        LocalTensor<U> tensor_index = queue_index.DeQue<U>();
        LocalTensor<T> tensor_src = queue_src.DeQue<T>();
        LocalTensor<T> tensor_y = queue_y.AllocTensor<T>();
        LocalTensor<float> tensor_res = buf_res.Get<float>();
        LocalTensor<U> tensor_cnt = buf_cnt.Get<U>();
        // reduce初值
        float init;
        if constexpr (reduce == 0 || reduce == 2) init = 0;
        if constexpr (reduce == 1) init = 1;
        if constexpr (reduce == 3) init = -1.0 / 0.0;
        if constexpr (reduce == 4) init = 1.0 / 0.0;
        for(int32_t k = 0; k < elems_per_task; ++k) {
            // 分别计算每一列
            Duplicate(tensor_res, init, dim_m);
            Duplicate(tensor_cnt, 0, dim_m);
            if constexpr (reduce == 0) { // sum
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task) {
                    int32_t idx = tensor_index(p);
                    tensor_res(idx) += static_cast<float>(tensor_src(p));
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self)
                            tensor_res(i) += static_cast<float>(tensor_self(p));
                        tensor_y(p) = tensor_res(i);
                    }
                    else tensor_y(p) = tensor_self(p);
            }
            if constexpr (reduce == 1) { // prod
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task) {
                    int32_t idx = tensor_index(p);
                    tensor_res(idx) *= static_cast<float>(tensor_src(p));
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self)
                            tensor_res(i) *= static_cast<float>(tensor_self(p));
                        tensor_y(p) = tensor_res(i);
                    }
                    else tensor_y(p) = tensor_self(p);
            }
            if constexpr (reduce == 2) { // mean
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task) {
                    int32_t idx = tensor_index(p);
                    tensor_res(idx) += static_cast<float>(tensor_src(p));
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self) {
                            tensor_res(i) += static_cast<float>(tensor_self(p));
                            tensor_cnt(i) += 1;
                        }
                        tensor_y(p) = tensor_res(i) / tensor_cnt(i);
                    }
                    else tensor_y(p) = tensor_self(p);
            }
            if constexpr (reduce == 3) { // amax
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task) {
                    int32_t idx = tensor_index(p);
                    float f = static_cast<float>(tensor_src(p));
                    if(f > tensor_res(idx)) tensor_res(idx) = f;
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self) {
                            float f = static_cast<float>(tensor_self(p));
                            if(f > tensor_res(i)) tensor_res(i) = f;
                        }
                        tensor_y(p) = tensor_res(i);
                    }
                    else tensor_y(p) = tensor_self(p);
            }
            if constexpr (reduce == 4) { // amin
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task) {
                    int32_t idx = tensor_index(p);
                    float f = static_cast<float>(tensor_src(p));
                    if(f < tensor_res(idx)) tensor_res(idx) = f;
                    tensor_cnt(idx) += 1;
                }
                for(int32_t i = 0, p = k; i < dim_m; ++i, p += elems_per_task)
                    if(tensor_cnt(i)) {
                        if constexpr (include_self) {
                            float f = static_cast<float>(tensor_self(p));
                            if(f < tensor_res(i)) tensor_res(i) = f;
                        }
                        tensor_y(p) = tensor_res(i);
                    }
                    else tensor_y(p) = tensor_self(p);
            }
        }
        queue_self.FreeTensor(tensor_self);
        queue_index.FreeTensor(tensor_index);
        queue_src.FreeTensor(tensor_src);
        queue_y.EnQue(tensor_y);
    }
    __aicore__ inline void CopyOut(int32_t h, int32_t c) {
        LocalTensor<T> tensor_y = queue_y.DeQue<T>();
        // 搬运输出
        DataCopyParams params{static_cast<uint16_t>(dim_m), 1, 0, static_cast<uint16_t>(block_l - 1)};
        DataCopy(global_y[h * dim_m * dim_l + c], tensor_y, params);
        queue_y.FreeTensor(tensor_y);
    }

private:
    TQue<QuePosition::VECIN, QUEUE_SIZE> queue_self, queue_index, queue_src;
    TBuf<QuePosition::VECCALC> buf_res, buf_cnt;
    TQue<QuePosition::VECOUT, QUEUE_SIZE> queue_y;
    GlobalTensor<T> global_self, global_src, global_y;
    GlobalTensor<U> global_index;
    int32_t dim_h, dim_m, dim_l, start, end, elems_per_task, block_l;
};

extern "C" __global__ __aicore__ void scatter_reduce(GM_ADDR self, GM_ADDR index, GM_ADDR src, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    if(tiling_data.dim_l == 1) {
        // 按行reduce：每行作为一个任务，DataCopyPad搬运，可以多线程
        if(tiling_data.include_self) {
            if(tiling_data.reduce == 0)
                KernelScatterReduceByRow<0, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 1)
                KernelScatterReduceByRow<1, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 2)
                KernelScatterReduceByRow<2, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 3)
                KernelScatterReduceByRow<3, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 4)
                KernelScatterReduceByRow<4, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
        } else {
            if(tiling_data.reduce == 0)
                KernelScatterReduceByRow<0, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 1)
                KernelScatterReduceByRow<1, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 2)
                KernelScatterReduceByRow<2, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 3)
                KernelScatterReduceByRow<3, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 4)
                KernelScatterReduceByRow<4, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.tasks_per_core);
        }
    } else if ((tiling_data.dim_l * sizeof(DTYPE_Y)) & 31) {
        // 按列reduce，每行不是32字节对齐：每列作为一个任务，GetValue搬运，单线程避免CacheLine互相覆盖
        if(tiling_data.include_self) {
            if(tiling_data.reduce == 0)
                KernelScatterReduceByColumnUnAligned<0, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 1)
                KernelScatterReduceByColumnUnAligned<1, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 2)
                KernelScatterReduceByColumnUnAligned<2, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 3)
                KernelScatterReduceByColumnUnAligned<3, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 4)
                KernelScatterReduceByColumnUnAligned<4, true> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
        } else {
            if(tiling_data.reduce == 0)
                KernelScatterReduceByColumnUnAligned<0, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 1)
                KernelScatterReduceByColumnUnAligned<1, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 2)
                KernelScatterReduceByColumnUnAligned<2, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 3)
                KernelScatterReduceByColumnUnAligned<3, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 4)
                KernelScatterReduceByColumnUnAligned<4, false> op(self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
        }
    } else {
        // 按列reduce，每行32字节对齐：每列32字节datablock作为一个任务，DataCopy搬运，可以多线程
        TPipe pipe;
        if(tiling_data.include_self) {
            if(tiling_data.reduce == 0)
                KernelScatterReduceByColumnAligned<0, true> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 1)
                KernelScatterReduceByColumnAligned<1, true> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 2)
                KernelScatterReduceByColumnAligned<2, true> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 3)
                KernelScatterReduceByColumnAligned<3, true> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 4)
                KernelScatterReduceByColumnAligned<4, true> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
        } else {
            if(tiling_data.reduce == 0)
                KernelScatterReduceByColumnAligned<0, false> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 1)
                KernelScatterReduceByColumnAligned<1, false> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 2)
                KernelScatterReduceByColumnAligned<2, false> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 3)
                KernelScatterReduceByColumnAligned<3, false> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
            else if(tiling_data.reduce == 4)
                KernelScatterReduceByColumnAligned<4, false> op(&pipe, self, index, src, y, tiling_data.dim_h, tiling_data.dim_m, tiling_data.dim_l, tiling_data.tasks_per_core);
        }
    }
}