
#include "heaviside_tiling.h"
#include "register/op_def_registry.h"


namespace optiling {
static ge::graphStatus TilingFunc(gert::TilingContext* context)
{
    // 获取平台信息
    // uint64_t ub_size;
    // auto ascendcPlatform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    // ascendcPlatform.GetCoreMemSize(platform_ascendc::CoreMemType::UB, ub_size);
    // int32_t num_cores = ascendcPlatform.GetCoreNum();
    // printf("ub size %ld\n", ub_size);
    // printf("core num %d\n", num_cores);
    uint64_t const ub_size = 196352;
    int32_t num_cores = 40;
    // 获取参数信息
    uint32_t elems_total = context->GetInputTensor(0)->GetShapeSize();
    uint32_t values_size = context->GetInputTensor(1)->GetShapeSize();
    auto dtype = context->GetInputTensor(0)->GetDataType();
    int32_t bytes_per_elem = 4 - dtype * 2; // 0=fp32=4, 1=fp16=2
    // 切片方案
    int32_t elems_per_task = 4096 / bytes_per_elem; // 以4k字节为最小单位
    int32_t tasks_total = (elems_total + elems_per_task - 1) / elems_per_task;
    int32_t tasks_per_core = (tasks_total + num_cores - 1) / num_cores;
    int32_t elems_per_core = elems_per_task * tasks_per_core;
    num_cores = (tasks_total + tasks_per_core - 1) / tasks_per_core;
    HeavisideTilingData tiling;
    tiling.set_elems_total(elems_total);
    tiling.set_elems_per_core(elems_per_core);
    tiling.set_values_size(values_size);
    // 设置线程数量、保存tiling结构体
    context->SetBlockDim(num_cores);
    // printf("num_cores: %d\n", num_cores);
    tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());
    context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());
    return ge::GRAPH_SUCCESS;
}
}


namespace ge {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    const gert::Shape* x1_shape = context->GetInputShape(0);
    gert::Shape* y_shape = context->GetOutputShape(0);
    *y_shape = *x1_shape;
    return GRAPH_SUCCESS;
}
}


namespace ops {
class Heaviside : public OpDef {
public:
    explicit Heaviside(const char* name) : OpDef(name)
    {
        this->Input("input")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("values")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("out")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});

        this->SetInferShape(ge::InferShape);

        this->AICore()
            .SetTiling(optiling::TilingFunc);
        this->AICore().AddConfig("ascend910b");

    }
};

OP_ADD(Heaviside);
}
