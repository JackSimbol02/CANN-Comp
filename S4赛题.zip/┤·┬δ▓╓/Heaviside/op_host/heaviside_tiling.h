
#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(HeavisideTilingData)
    TILING_DATA_FIELD_DEF(uint32_t, elems_total);
    TILING_DATA_FIELD_DEF(int32_t, elems_per_core);
    TILING_DATA_FIELD_DEF(uint32_t, values_size);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(Heaviside, HeavisideTilingData)
}
